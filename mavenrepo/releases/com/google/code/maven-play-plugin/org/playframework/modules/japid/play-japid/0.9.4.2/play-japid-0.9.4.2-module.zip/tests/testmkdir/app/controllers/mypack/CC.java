package testmkdir.app.controllers.mypack;

public class CC {

}
