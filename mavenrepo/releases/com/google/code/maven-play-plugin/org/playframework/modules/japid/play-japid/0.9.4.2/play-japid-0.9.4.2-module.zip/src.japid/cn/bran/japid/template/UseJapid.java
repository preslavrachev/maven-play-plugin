package cn.bran.japid.template;

/**
 * a marker interface to mark those class that use JapidRender.render() for
 * automatic template binding
 * 
 * @author Bing Ran<bing_ran@hotmail.com>
 * @deprecated not used. 
 */
public interface UseJapid {

}
