package models;

import com.google.code.morphia.annotations.Entity;

@SuppressWarnings("serial")
@Entity
public class Extend extends Base {

}
