package cn.bran.japid.compiler;

public enum OpMode {
	dev, // a mode that allow template reloading on the fly
	prod // static mode for best performance
}
