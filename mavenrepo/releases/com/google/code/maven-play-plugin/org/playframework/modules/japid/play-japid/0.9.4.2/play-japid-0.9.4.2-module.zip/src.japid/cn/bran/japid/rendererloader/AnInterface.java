package cn.bran.japid.rendererloader;

public interface AnInterface {

}
