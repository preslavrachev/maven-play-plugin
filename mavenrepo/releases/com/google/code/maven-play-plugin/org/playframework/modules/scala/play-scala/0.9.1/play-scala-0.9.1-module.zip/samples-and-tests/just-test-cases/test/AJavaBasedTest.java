import org.junit.*;
import play.test.*;

public class AJavaBasedTest extends UnitTest {
    
    @Test
    public void justCheckThatItWorks() {
        assertEquals("HOP", "HOP");
    }
    
}