package controllers.t3;

import cn.bran.play.JapidController;
public class App extends JapidController {
	public static void foo() {
		renderText("hi foo  ");
	}
}
