package services.exception;

/**
 * 
 * @author tkral
 */
public class RegistrationPasswordException extends RuntimeException {

	public RegistrationPasswordException(String message) {
		super(message);
	}
}
