package models

object Apple {
    var tname = "Apple 99"
    
    def name = tname
    
    def asUser = new Company("xx", "xx")  
}

object Orange {
    var tname = "Orange 999999"
    
    def name = tname
    
    def asUser = new Company("xx", "xx")  
}