package models;

import org.bson.types.ObjectId;

import play.modules.morphia.Model;

import com.google.code.morphia.annotations.Entity;
import com.google.code.morphia.annotations.Id;


@SuppressWarnings("serial")
public abstract class Base extends Model {
}
