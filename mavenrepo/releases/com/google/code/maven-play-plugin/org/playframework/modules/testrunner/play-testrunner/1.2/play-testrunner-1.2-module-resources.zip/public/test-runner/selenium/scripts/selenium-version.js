Selenium.version = "1.0.1";
Selenium.revision = "final";

window.top.document.title += " - Selenium v" + Selenium.version + " [" + Selenium.revision + "]";

