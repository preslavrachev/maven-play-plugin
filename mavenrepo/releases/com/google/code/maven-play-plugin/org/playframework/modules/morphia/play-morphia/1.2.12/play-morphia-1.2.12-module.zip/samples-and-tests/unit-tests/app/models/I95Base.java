package models;

/**
 * Created with IntelliJ IDEA.
 * User: luog
 * Date: 24/10/12
 * Time: 11:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class I95Base {
    public String c;
}
