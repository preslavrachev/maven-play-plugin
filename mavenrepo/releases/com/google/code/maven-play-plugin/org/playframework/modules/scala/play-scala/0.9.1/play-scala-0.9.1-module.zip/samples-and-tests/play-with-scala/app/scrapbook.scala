package play_with_scala {

    class Scrapbook {
        print("Howdy, open the app/scrapbook.scala file, and start to Play!") 
    }

}
