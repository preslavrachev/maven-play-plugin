package controllers;

import play.*;
import play.mvc.*;

import java.util.*;

/**
 * 
 * @author Olivier Refalo
 */
public class Application extends Controller {

    public static void index() {
        render();
    }
}
