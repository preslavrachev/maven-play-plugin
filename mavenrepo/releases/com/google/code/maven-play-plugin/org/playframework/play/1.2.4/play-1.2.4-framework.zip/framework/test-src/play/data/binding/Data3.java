package play.data.binding;


import java.util.HashMap;
import java.util.Map;

class Data3 {
    public String a;
    public Map<String, String> map = new HashMap<String, String>();
}
