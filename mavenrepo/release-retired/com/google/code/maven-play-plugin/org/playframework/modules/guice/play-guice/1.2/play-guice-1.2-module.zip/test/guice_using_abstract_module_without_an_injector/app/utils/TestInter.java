package utils;

public interface TestInter {
	public String printer();
}
