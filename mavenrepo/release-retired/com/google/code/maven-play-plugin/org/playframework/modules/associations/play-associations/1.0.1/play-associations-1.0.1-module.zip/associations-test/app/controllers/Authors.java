package controllers;

public class Authors extends CRUD {

    
}
