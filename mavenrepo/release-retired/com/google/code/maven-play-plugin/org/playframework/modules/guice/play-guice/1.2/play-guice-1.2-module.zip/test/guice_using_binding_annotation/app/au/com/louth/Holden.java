package au.com.louth;

public class Holden implements Car {

	@Override
	public String drive() {
		return "Driving a Holden";
	}

}
