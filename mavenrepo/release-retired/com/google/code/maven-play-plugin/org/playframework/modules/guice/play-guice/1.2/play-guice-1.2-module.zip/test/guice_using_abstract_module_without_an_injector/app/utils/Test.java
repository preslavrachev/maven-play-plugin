package utils;

public class Test implements TestInter{

	public String printer(){
		return "yay!";
	}
}
