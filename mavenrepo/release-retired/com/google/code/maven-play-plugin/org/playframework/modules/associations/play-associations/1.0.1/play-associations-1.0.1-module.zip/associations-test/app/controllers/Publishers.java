package controllers;


public class Publishers extends CRUD {

    
}
