package play.modules.springtester;

public final class MockitoFactory {

    public static Object create(Object object) {
        return object;
    }
}
