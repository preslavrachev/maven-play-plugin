package com.postmark.java;

public enum PostmarkStatus {
    UNKNOWN, SUCCESS, USERERROR, SERVERERROR
}
